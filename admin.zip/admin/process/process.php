<?php
include_once('../include/function.php');
$db= new functions();
/*$action= isset($_REQUEST['action'])?($_REQUEST['action']):array();
switch($action)
{
	case 'login': login(); break;
	default: $db->redirect('../index.php');
}
*/
if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'login')
{
	$sql = "select * from tbl_admin where admin_email='".$_REQUEST['email']."' and admin_pass = '".$_REQUEST['password']."'";
	$run = $db->query($sql);
	if(mysqli_num_rows($run) > 0)
	{
		$row = mysqli_fetch_assoc($run);
		$_SESSION['is_admin_logged_id'] = true;
		$_SESSION['admin_id'] = $row['admin_id'];
		$_SESSION['admin_email'] = $row['admin_email'];
		$db->query("update tbl_admin set admin_last_login = '".date('Y-m-d')."' where admin_id = '".$row['admin_id']."'");
		
		$_SESSION['success'] = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success!</strong> Welcome '.$row['admin_email'].'.</div>';
		$db->redirect('../index.php');
	}
	else
	{
		$_SESSION['error'] = '<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Error!</strong> Login-Id or Password in correct.</div>';
		$db->redirect('../login.php');	
	}
}

/*else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'add_cat')
{
	echo 'sfd';
	if($run)
	{
		$_SESSION['success'] = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success!</strong> Menu update  Successfully.</div>';
		$db->redirect('../listmenu.php');
	}
	else
	{
		$_SESSION['error'] = '<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Error!</strong> Please try again.</div>';
		$db->redirect('../listmenu.php');	
	}
}*/

else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'update_profile')
{
	$sql = "update tbl_admin set admin_name = '".$_REQUEST['name']."', admin_email = '".$_REQUEST['email']."' where admin_id = '".$_REQUEST['id']."'";
	$run = $db->query($sql);
	if($run)
	{
		$_SESSION['success'] = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success!</strong> Your Profile is updated Successfully.</div>';
		$db->redirect('../profile.php');
	}
	else
	{
		$_SESSION['error'] = '<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Error!</strong> Please try again.</div>';
		$db->redirect('../profile.php');	
	}
}

else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'change_password')
{
	$sql = "select * from tbl_admin where admin_id = '".$_REQUEST['id']."'";
	$run = $db->query($sql);
	$row = mysqli_fetch_assoc($run);
	if($row['admin_pass'] == $_REQUEST['Current_Password'])
	{
		$sql = "update tbl_admin set admin_pass = '".$_REQUEST['New_Password']."' where admin_id = '".$_REQUEST['id']."'";
		$run = $db->query($sql);
		echo 1;
	}
	else
	{
		echo 0;
	}
}
else
{
	echo '<pre>';
	print_r($_REQUEST);
	print_r($_FILES);
	echo '<h1>Your Action Is Wrong</h1>';
}
?>